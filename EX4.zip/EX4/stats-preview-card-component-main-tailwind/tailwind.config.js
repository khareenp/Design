module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        "dark-blue": "hsl(233, 47%, 7%)",
        "desat-blue": "hsl(244, 38%, 16%)",
        "soft-violet": "hsl(277, 64%, 61%)",
        white: "hsl(0, 0%, 100%)",
        "white-p": "hsla(0, 0%, 100%, 0.75)",
        "white-a": "hsla(0, 0%, 100%, 0.6)",
      },
      fontFamily: {
        "lexend-deca": ["Inter", "sans - serif"],
      },
    },
  },
  plugins: [],
};
