module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {},
    fontFamily: {
      custom: ["Inter", "sans-serf"],
      Outfit: ["Outfit", "sans-serf"],
    },
  },
  plugins: [],
};
